class EuclideanAlgorithmError(Exception):
    def __str__(self):
        return "Entered numbers must be greater than 0"
