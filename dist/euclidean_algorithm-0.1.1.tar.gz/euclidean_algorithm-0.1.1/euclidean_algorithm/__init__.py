__all__ = (
    "euclidean_algorithm"
)

from .euclidean_algorithm import euclidean_algorithm

__author__ = "Hspu1"
__version__ = "0.1.2"
__email__ = "rumyantsev1m0s1@gmail.com"
