from numba import jit, TypingError


class EuclideanAlgorithmValueError(Exception):
    def __str__(self):
        return "Entered numbers must be greater than 0"


class EuclideanAlgorithmLengthError(Exception):
    def __str__(self):
        return ("The number of digits in the entered numbers "
                "should not exceed 20")


@jit(fastmath=True, cache=True)
def euclidean_algorithm_calculating(num1: int, num2: int
                            ) -> int | float | EuclideanAlgorithmValueError:
    if num1 <= 0 or num2 <= 0:
        raise EuclideanAlgorithmValueError
    elif num2 % num1 == 0 or num1 % num2 == 0:
        return num1 if num1 < num2 else num2

    while True:
        if num1 > num2:
            while num1 > num2:
                num1 -= num2
        elif num2 > num1:
            while num2 > num1:
                num2 -= num1

        if num1 == num2:
            return num1


def euclidean_algorithm(num1: int, num2: int
                            ) -> int | float | EuclideanAlgorithmLengthError:
    try:
        euclidean_algorithm_calculating(num1=num1, num2=num2)
    except TypingError:
        raise EuclideanAlgorithmLengthError
    else:
        return euclidean_algorithm_calculating(num1=num1, num2=num2)
